import { BuscaRestaurantePipe } from './busca-restaurante.pipe';

describe('BuscaRestaurantePipe', () => {
  it('create an instance', () => {
    const pipe = new BuscaRestaurantePipe();
    expect(pipe).toBeTruthy();
  });
});
