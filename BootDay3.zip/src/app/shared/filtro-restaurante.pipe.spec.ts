import { FiltroRestaurantePipe } from './filtro-restaurante.pipe';

describe('FiltroRestaurantePipe', () => {
  it('create an instance', () => {
    const pipe = new FiltroRestaurantePipe();
    expect(pipe).toBeTruthy();
  });
});
