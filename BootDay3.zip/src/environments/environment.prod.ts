export const environment = {
  production: true,
    firebaseConfig: {
      apiKey: "AIzaSyDDJFE6xzc5Mi-FjHRSlbmVUaWtmyBsp5M",
      authDomain: "findfood-restaurante.firebaseapp.com",
      projectId: "findfood-restaurante",
      storageBucket: "findfood-restaurante.appspot.com",
      messagingSenderId: "700361245845",
      appId: "1:700361245845:web:5f24a3565ce5077152879c"
    }
};
